from django.urls import path
from . import views

app_name= "teacher"

urlpatterns = [
    path('teacher_dashboard/', views.teacher_dashboard, name='teacher_dashboard'),
    path('student-attendance/', views.student_attendance_view, name='student_attendance'),
    path('view-student-attendance/', views.view_student_attendance, name='view_student_attendance'),
    path('rewrite_student_attendance/<pk>/', views.rewrite_student_attendance, name='rewrite_student_attendance'),
]
