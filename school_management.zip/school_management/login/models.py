from django.db import models
from django.contrib.auth.models import AbstractUser
from .manager import UserManager


#role table
class Role(models.Model):
    role_name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.role_name


#custom user

class CustomUser(AbstractUser):
    
    username = None
    email =models.EmailField(unique = True)
   
    role = models.ForeignKey(Role, on_delete=models.SET_NULL, null=True, blank=True)

    objects = UserManager()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []