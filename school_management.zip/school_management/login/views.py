from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login
from django.contrib import messages

def custom_login(request):
    if request.method == 'POST':
        email = request.POST['email']
        password = request.POST['password']
        user = authenticate(request, email=email, password=password)
        
        if user is not None:
            login(request, user)
            # Check the user's role_id and redirect accordingly
            if user.role_id == 1:
                return redirect('administrator:admin_dashboard')  # Redirect to admin_dashboard.html
            elif user.role_id == 2:
                return redirect('teacher:teacher_dashboard')  # Redirect to teacher_dashboard.html
            else:
                return redirect('home')  # Redirect to a default home page or another dashboard
        
        else:
            messages.error(request, 'Invalid email or password')
            return redirect('login:login')
    
    return render(request, 'login.html')


from django.shortcuts import redirect
from django.contrib.auth import logout
from django.contrib.auth.decorators import login_required

@login_required
def custom_logout(request):
    logout(request)
    return redirect('login:login')
