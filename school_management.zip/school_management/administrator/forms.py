from django import forms
from .models import AcademicYear

class AcademicYearForm(forms.ModelForm):
    class Meta:
        model = AcademicYear
        fields = ['start_year', 'end_year']

#stander

from django import forms
from .models import Standard

class StandardForm1(forms.ModelForm):
    class Meta:
        model = Standard
        fields = ['class_field', 'division']

    def clean(self):
        cleaned_data = super().clean()
        class_field = cleaned_data.get('class_field')
        division = cleaned_data.get('division')

        if Standard.objects.filter(class_field=class_field, division=division).exists():
            raise forms.ValidationError("This combination of class and division already exists.")

# forms.py inside the 'administrator' app
from django import forms
from .models import Teacher, CustomUser

class CustomUserForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(), required=False)  # Optional password field

    class Meta:
        model = CustomUser
        fields = ['first_name', 'last_name', 'email', 'password']

class TeacherForm(forms.ModelForm):
    class Meta:
        model = Teacher
        fields = ['shift', 'gender', 'photo', 'date_of_birth', 'salary', 'contact_no', 'address']

#fee
# forms.py

# 
from django import forms
from administrator.models import Standard, StudentAttendance

class StandardForm(forms.Form):
    standard = forms.ModelChoiceField(queryset=Standard.objects.all(), label="Select Standard", required=True)

class StudentAttendanceForm(forms.ModelForm):
    class Meta:
        model = StudentAttendance
        fields = ['date', 'status', 'academic_year']
        widgets = {
            'date': forms.SelectDateWidget(),
            'status': forms.RadioSelect(choices=[('Present', 'Present'), ('Absent', 'Absent')]),
        }


from django import forms
from administrator.models import StudentAttendance

class rewriteAttendanceForm(forms.ModelForm):
    class Meta:
        model = StudentAttendance
        fields = ('status',)